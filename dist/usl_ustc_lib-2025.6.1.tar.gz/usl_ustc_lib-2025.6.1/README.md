# USL_USTC_lib

## Introduction

USL_USC_lib is a python package for ultra-stable laser system researching in USTC, it includings many functions for data deal and calculation, like read TCH data and calculate its PSD and Allan deviation.